#ifndef _SURVIVAL_STAT_H_
#define _SURVIVAL_STAT_H_

#include "survival_func.h"
#include "survival_kaplan_meier.h"

#endif